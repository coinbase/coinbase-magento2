<?php
use \Magento\Framework\Component\ComponentRegistrar;
ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Coinbase_Magento2PaymentGateway', __DIR__);
